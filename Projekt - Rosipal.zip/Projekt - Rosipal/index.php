<?php
    $data = simplexml_load_file("Proizvodi.xml");
    $EDPZ = [];
    $EDPM = [];
    $EDT = [];
    
    foreach($data->children() as $subject){
        if(isset($subject->EDPZ)){
            foreach($subject->EDPZ as $edpz_data){
                $edpz[] = $edpz_data;
            }
        }
        if(isset($subject->EDPM)){
            foreach($subject->EDPM as $edpm_data){
                $edpm[] = $edpm_data;
            }
        }
        if(isset($subject->EDT)){
            foreach($subject->EDT as $edt_data){
                $edt[] = $edt_data;
            }
        }
    }
    
?>

<!DOCTYPE html>
    <head>
        <title>Webshop</title>
        <meta charset="UTF-8"/>

    <style>
  #header {
    background-color: black;
    color: whitesmoke;
    margin: auto;
    border: 0px;
    padding: 20px;
    text-align: center;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 50px;
    overflow: hidden;
    width: 100%;
}

footer {
    background-color: black;
    color: rgb(131, 126, 126);
    margin: 0px;
    border: 0px;
    padding: 20px;
    text-align: center;
    font-family: Arial, Helvetica, sans-serif;
}
   
h3 {
    font-family: 'Anton', sans-serif;
    color: pink;
    text-align: center;
    font-size: 25px;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    color: gray;
    text-align: center;
}

article.popust {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    color: pink;
    text-decoration: line-through;
}

.button {
    background-color: #4CAF50; 
    border: none;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    padding: 5px;
    margin: 10px;
    border-radius: 10px;
    font-size: 16px;
    transition-duration: 0.4s;
}

.button {
    background-color: white; 
    color: black; 
    border: 2px solid black;
}

.button:hover {
    background-color: pink;
    color: white;
}

.container {
    text-align: center;
    color: white;
}

.flex-container {
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: center;
    padding: 20px;
}

.red {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    width: 60%;
}

.stupac {
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    flex-basis: 100%;
    flex: 1;
    padding: 30px;
    justify-content: center;
    text-align: center;
  
}

.slika{
    height: 200px;
    width: 200px;
    margin-bottom:50px;
}


@media screen and (max-width: 600px){
    .flex-container {
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;
        align-items: center;
        padding: 20px;
    }
    .red {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        width: 60%;
        
    }

    .stupac {
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        flex-basis: 100%;
        padding: 20px;
    }
}

  </style>




    </head>
    <body>
        <!--Zaglavlje stranice-->
        <header class="row">
            <h1 id="header">NOTINO</h1>
        </header>

        <!--Main-->
        <div class="flex-container">
            <div class="red">
                <div class="stupac">
                    <img src="Images/Parfemi/1.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpz[0]->marka;?> - EDP</h3>
                    <?php echo $edpz[0]->vrsta;?>
                    <article class="popust"></br><?php echo $edpz[0]->cijena;?></article>
                    <?php echo $edpz[0]->cijena_popust;?>
                    <button class="button"> KUPI </button>

                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/2.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpz[1]->marka;?> - EDP</h3>
                    <?php echo $edpz[1]->vrsta;?>
                    <article class="popust"></br><?php echo $edpz[1]->cijena;?></article>
                    <?php echo $edpz[1]->cijena_popust;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/3.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpz[2]->marka;?> - EDP</h3>
                    <?php echo $edpz[2]->vrsta;?>
                    <article class="popust"></br><?php echo $edpz[2]->cijena;?></article>
                    <?php echo $edpz[2]->cijena_popust;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/4.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpz[3]->marka;?> - EDP</h3>
                    <?php echo $edpz[3]->vrsta;?>
                    <article class="popust"></br><?php echo $edpz[3]->cijena;?></article>
                    <?php echo $edpz[3]->cijena_popust;?>
                    <button class="button"> KUPI </button>
                </div>
            </div>
            <div class="red">
                <div class="stupac">
                    <img src="Images/Parfemi/5.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpm[0]->marka;?> - EDP</h3>
                    <?php echo $edpm[0]->vrsta;?>
                    </br></br>
                    <?php echo $edpm[0]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/6.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpm[1]->marka;?> - EDP</h3>
                    <?php echo $edpm[1]->vrsta;?>
                    </br></br>
                    <?php echo $edpm[1]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/7.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpm[2]->marka;?> - EDP</h3>
                    <?php echo $edpm[2]->vrsta;?>
                    </br></br>
                    <?php echo $edpm[2]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="Images/Parfemi/8.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edpm[3]->marka;?> - EDP</h3>
                    <?php echo $edpm[3]->vrsta;?>
                    </br></br>
                    <?php echo $edpm[3]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
            </div>
            <div class="red">
                <div class="stupac">
                    <img src="images/Parfemi/9.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edt[0]->marka;?> - EDT</h3>
                    <?php echo $edt[0]->vrsta;?>
                    </br></br>
                    <?php echo $edt[0]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="images/Parfemi/10.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edt[1]->marka;?> - EDT</h3>
                    <?php echo $edt[1]->vrsta;?>
                    </br></br>
                    <?php echo $edt[1]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="images/Parfemi/11.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edt[2]->marka;?> - EDT</h3>
                    <?php echo $edt[2]->vrsta;?>
                    </br></br>
                    <?php echo $edt[2]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
                <div class="stupac">
                    <img src="images/Parfemi/12.WEBP" style="max-width: 100%; padding: 10px;" class='slika'>
                    <h3><?php echo $edt[3]->marka;?> - EDT</h3>
                    <?php echo $edt[3]->vrsta;?>
                    </br></br>
                    <?php echo $edt[3]->cijena;?>
                    <button class="button"> KUPI </button>
                </div>
            </div>
        </div>
        
        <!--Footer-->
        <footer>
            Petra Rosipal
            <br/>
            Informatički dizajn
        </footer>
    </body>
</html>